/****************************************************************************
** Meta object code from reading C++ file 'tabwidget.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/tabwidget.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tabwidget.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TabWidget_t {
    QByteArrayData data[30];
    char stringdata0[282];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TabWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TabWidget_t qt_meta_stringdata_TabWidget = {
    {
QT_MOC_LITERAL(0, 0, 9), // "TabWidget"
QT_MOC_LITERAL(1, 10, 18), // "currentTextChanged"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 7), // "newtext"
QT_MOC_LITERAL(4, 38, 13), // "undoAvailable"
QT_MOC_LITERAL(5, 52, 9), // "available"
QT_MOC_LITERAL(6, 62, 13), // "redoAvailable"
QT_MOC_LITERAL(7, 76, 13), // "copyAvailable"
QT_MOC_LITERAL(8, 90, 13), // "newFileCreate"
QT_MOC_LITERAL(9, 104, 16), // "openFilesClicked"
QT_MOC_LITERAL(10, 121, 9), // "saveclick"
QT_MOC_LITERAL(11, 131, 6), // "saveas"
QT_MOC_LITERAL(12, 138, 7), // "saveAll"
QT_MOC_LITERAL(13, 146, 11), // "saveSession"
QT_MOC_LITERAL(14, 158, 4), // "undo"
QT_MOC_LITERAL(15, 163, 4), // "redo"
QT_MOC_LITERAL(16, 168, 3), // "cut"
QT_MOC_LITERAL(17, 172, 4), // "copy"
QT_MOC_LITERAL(18, 177, 5), // "paste"
QT_MOC_LITERAL(19, 183, 4), // "find"
QT_MOC_LITERAL(20, 188, 7), // "setFont"
QT_MOC_LITERAL(21, 196, 6), // "QFont*"
QT_MOC_LITERAL(22, 203, 7), // "newFont"
QT_MOC_LITERAL(23, 211, 8), // "closetab"
QT_MOC_LITERAL(24, 220, 5), // "index"
QT_MOC_LITERAL(25, 226, 13), // "changetabname"
QT_MOC_LITERAL(26, 240, 9), // "Textedit*"
QT_MOC_LITERAL(27, 250, 8), // "textedit"
QT_MOC_LITERAL(28, 259, 6), // "edited"
QT_MOC_LITERAL(29, 266, 15) // "onCurrentChange"

    },
    "TabWidget\0currentTextChanged\0\0newtext\0"
    "undoAvailable\0available\0redoAvailable\0"
    "copyAvailable\0newFileCreate\0"
    "openFilesClicked\0saveclick\0saveas\0"
    "saveAll\0saveSession\0undo\0redo\0cut\0"
    "copy\0paste\0find\0setFont\0QFont*\0newFont\0"
    "closetab\0index\0changetabname\0Textedit*\0"
    "textedit\0edited\0onCurrentChange"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TabWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  114,    2, 0x06 /* Public */,
       4,    1,  117,    2, 0x06 /* Public */,
       6,    1,  120,    2, 0x06 /* Public */,
       7,    1,  123,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  126,    2, 0x0a /* Public */,
       9,    0,  127,    2, 0x0a /* Public */,
      10,    0,  128,    2, 0x0a /* Public */,
      11,    0,  129,    2, 0x0a /* Public */,
      12,    0,  130,    2, 0x0a /* Public */,
      13,    0,  131,    2, 0x0a /* Public */,
      14,    0,  132,    2, 0x0a /* Public */,
      15,    0,  133,    2, 0x0a /* Public */,
      16,    0,  134,    2, 0x0a /* Public */,
      17,    0,  135,    2, 0x0a /* Public */,
      18,    0,  136,    2, 0x0a /* Public */,
      19,    0,  137,    2, 0x0a /* Public */,
      20,    1,  138,    2, 0x0a /* Public */,
      23,    1,  141,    2, 0x08 /* Private */,
      25,    3,  144,    2, 0x08 /* Private */,
      29,    0,  151,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, 0x80000000 | 26, QMetaType::QString, QMetaType::Bool,   27,    3,   28,
    QMetaType::Void,

       0        // eod
};

void TabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TabWidget *_t = static_cast<TabWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->currentTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->undoAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->redoAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->copyAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->newFileCreate(); break;
        case 5: _t->openFilesClicked(); break;
        case 6: _t->saveclick(); break;
        case 7: _t->saveas(); break;
        case 8: _t->saveAll(); break;
        case 9: _t->saveSession(); break;
        case 10: _t->undo(); break;
        case 11: _t->redo(); break;
        case 12: _t->cut(); break;
        case 13: _t->copy(); break;
        case 14: _t->paste(); break;
        case 15: _t->find(); break;
        case 16: _t->setFont((*reinterpret_cast< QFont*(*)>(_a[1]))); break;
        case 17: _t->closetab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->changetabname((*reinterpret_cast< Textedit*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 19: _t->onCurrentChange(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Textedit* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TabWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::currentTextChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::undoAvailable)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::redoAvailable)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (TabWidget::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::copyAvailable)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject TabWidget::staticMetaObject = {
    { &QTabWidget::staticMetaObject, qt_meta_stringdata_TabWidget.data,
      qt_meta_data_TabWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *TabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TabWidget.stringdata0))
        return static_cast<void*>(this);
    return QTabWidget::qt_metacast(_clname);
}

int TabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void TabWidget::currentTextChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TabWidget::undoAvailable(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TabWidget::redoAvailable(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void TabWidget::copyAvailable(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
